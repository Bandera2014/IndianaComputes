class Song:
     
     def __init__(self,title,artist,album,rating):
          self.title = title
          self.artist = artist
          self.album = album
          self.rating = rating
     
     def __str__(self):
          return f"""
          Title: {self.title}
          Artist: {self.artist}
          Album: {self.album}
          Rating: {self.rating}/10
          """
     def fileformat(self):
          return f"S\t{self.title}\t{self.artist}\t{self.album}\t{self.rating}\n"

