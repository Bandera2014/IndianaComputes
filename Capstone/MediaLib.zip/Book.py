class Book:

     def __init__(self,title,author,genre,isbn,rating):
          self.title = title
          self.author = author
          self.genre = genre
          self.isbn = isbn
          self.rating = rating
     
     def __str__(self):
          return f"""
          Title: {self.title}
          Author: {self.author}
          Genre: {self.genre}
          ISBN: {self.isbn}
          Rating: {self.rating}/10
          """

     def modifyTitle(self,newTitle):
          self.title=newTitle

     def modifyAuthor(self,newAuthor):
          self.author=newAuthor

     def modifyGenre(self,newGenre):
          self.genre=newGenre

     def modifyISBN(self,correctedISBN):
          self.isbn=correctedISBN

     def modifyRating(self,r):
          self.rating=r

     def fileformat(self):
          return f"B\t{self.title}\t{self.author}\t{self.genre}\t{self.isbn}\t{self.rating}\n"


