from Book import Book
from Song import Song
filename="lib.txt"
library = []
'''
     bandersBook1 = Book('Great Gatsby','Scott Fitzgerald','Reality Soap Opera',2,4)
     bandersBook2 = Book('Fehrenheit 451','Ray Bradbury','Sensoring',3,8)
     bandersBook3 = Book('Lord of the Flies','Piggy','Survivor',1,10)

     print(bandersBook1, bandersBook2)

     bandersBook1.modifyRating(7)
     print(bandersBook1, bandersBook2)

     #print just the title of a book
     print(bandersBook1.title)
'''

file=open(filename,"r")
for line in file:
     if line[0]=="B":
          temp=line.split("\t")
          b=Book(temp[1],temp[2],temp[3],temp[4],temp[5].rstrip())
          '''
               Need to check if object b's title has Harry Potter in it.
                    If so, run the functions here to modify the information to what 
                    it needs to be.  I will do the author one for you.
                    b.modifyAuthor("JK Rawling")
               
               When the loop is done reading, you can just rewrite the library to the 
                    file just like what we do later in this code.
          '''
          library.append(b)
     elif line[0]=="S":
          temp=line.split("\t")
          s=Song(temp[1],temp[2],temp[3],temp[4].rstrip())
          library.append(s)

file.close()
for media in library:
     print(media)


ui=input("Do you have book for your library? (enter q to stop) ")
#loop until the user says stop and create their library of books
while ui != "q":
     if input("b for book or s for song") == "b":
          t=input("title: ")
          i=input("author: ")
          g=input("genre: ")
          e=input("isbn: ")
          r=input("rating: ")
          b=Book(t,i,g,e,r)   #I spelled out tiger....  hehehe
          library.append(b)
     else:
          library.append(Song(
                              input("title: "),
                              input("artist: "),
                              input("album: "),
                              input("rating: ")
                         )
          )
     ui=input("Do you have book for your library? (enter q to stop) ")
     #when user says stop, print out each book

#write my library to a text file

file=open(filename,"w")

for media in library:
     file.write(media.fileformat())
file.close()

